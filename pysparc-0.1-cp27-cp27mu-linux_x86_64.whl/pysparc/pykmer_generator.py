'''
Created on Sep 7, 2018

@author: Lizhen Shi
'''

_RC = {'A' : 'T', 'T' : 'A', 'C' : 'G', 'G' : 'C', 'N' : 'N'}


def canonical_kmer(seq):
    rc = reverse_complement(seq)
    return rc if (rc < seq) else seq


def reverse_complement(seq):
    return "".join([_RC[c] for c in seq[::-1]])

    
def _generate_kmer(seq, k, canonical):
    kmers = []
    for i in range(0 , (len(seq) - k) + 1):
        subseq = seq[i:i + k]
        kmers.append(subseq)
    kmers = list(set(kmers))
    if canonical:
        kmers = [canonical_kmer(subseq) for subseq in kmers]
    return list(set(kmers))


# generates kmers hash values given the seq (doesn't handle 'N' and reverse complement)
def generate_kmer(seq, k, err_char="N", canonical=True):
    lst = []
    for subseq in seq.split(err_char):
        lst += _generate_kmer(subseq, k, canonical=canonical)
        lst += _generate_kmer(reverse_complement(subseq), k, canonical=canonical)
    return list(set(lst))
